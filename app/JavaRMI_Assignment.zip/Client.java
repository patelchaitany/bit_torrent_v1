import java.rmi.*;

public class Client {
    public static void main(String args[]) {
        try {
            Calculator c = (Calculator) Naming.lookup("rmi://localhost:5000/CalculatorService");
            System.out.println("Addition: " + c.add(10, 5));
            System.out.println("Subtraction: " + c.subtract(10, 5));
            System.out.println("Multiplication: " + c.multiply(10, 5));
            System.out.println("Division: " + c.divide(10, 5));
        } catch (Exception e) {
            System.out.println("Client Error: " + e);
        }
    }
}
