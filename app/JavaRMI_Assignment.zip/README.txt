# Java RMI Assignment - Remote Calculator

## Files
1. Calculator.java (Interface)
2. CalculatorImpl.java (Implementation)
3. Server.java (Server)
4. Client.java (Client)

## Steps to Run
1. Compile all files:
   javac *.java

2. Start RMI registry (on port 5000):
   rmiregistry 5000 &

3. Start Server:
   java Server

4. Run Client:
   java Client

